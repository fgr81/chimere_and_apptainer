/*
 * Copyright (c) 2011      Cisco Systems, Inc.  All rights reserved.
 * $COPYRIGHT$
 *
 * Additional copyrights may follow
 *
 * $HEADER$
 */

#ifndef ORTE_ESS_PMI_H
#define ORTE_ESS_PMI_H

BEGIN_C_DECLS

ORTE_MODULE_DECLSPEC extern orte_ess_base_component_t mca_ess_pmi_component;

END_C_DECLS

#endif /* ORTE_ESS_PMI_H */
