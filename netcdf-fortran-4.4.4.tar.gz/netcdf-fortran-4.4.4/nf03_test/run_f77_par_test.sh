#mpd&
mpiexec -n 4 ./f03tst_parallel
